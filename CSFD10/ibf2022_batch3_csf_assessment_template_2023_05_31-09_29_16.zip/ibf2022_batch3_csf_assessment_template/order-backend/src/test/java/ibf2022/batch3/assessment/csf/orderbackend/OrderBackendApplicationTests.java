package ibf2022.batch3.assessment.csf.orderbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
