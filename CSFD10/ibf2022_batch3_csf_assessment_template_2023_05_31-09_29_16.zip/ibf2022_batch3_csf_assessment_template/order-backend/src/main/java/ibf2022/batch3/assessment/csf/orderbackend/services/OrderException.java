package ibf2022.batch3.assessment.csf.orderbackend.services;

public class OrderException extends Exception {

	public OrderException() { }

	public OrderException(String msg) {
		super(msg);
	}
}
