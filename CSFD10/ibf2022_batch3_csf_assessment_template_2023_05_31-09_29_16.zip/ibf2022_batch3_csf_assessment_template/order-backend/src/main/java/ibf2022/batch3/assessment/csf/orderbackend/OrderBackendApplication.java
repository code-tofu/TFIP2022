package ibf2022.batch3.assessment.csf.orderbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderBackendApplication.class, args);
	}

}
