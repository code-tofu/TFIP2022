package ibf2022.batch3.assessment.csf.orderbackend.respositories;

import ibf2022.batch3.assessment.csf.orderbackend.models.PizzaOrder;

public class PendingOrdersRepository {

	// TODO: Task 3
	// WARNING: Do not change the method's signature.
	public void add(PizzaOrder order) {
	}

	// TODO: Task 7
	// WARNING: Do not change the method's signature.
	public boolean delete(String orderId) {
		return false;
	}

}
