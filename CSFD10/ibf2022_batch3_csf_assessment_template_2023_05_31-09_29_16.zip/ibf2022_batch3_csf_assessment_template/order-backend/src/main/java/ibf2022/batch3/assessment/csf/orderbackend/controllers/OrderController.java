package ibf2022.batch3.assessment.csf.orderbackend.controllers;

public class OrderController {

	// TODO: Task 3 - POST /api/order


	// TODO: Task 6 - GET /api/orders/<email>


	// TODO: Task 7 - DELETE /api/order/<orderId>

}
