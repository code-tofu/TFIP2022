package ibf2022.batch2.ssf.frontcontroller.respositories;

public class AuthenticationRepository {

	// TODO Task 5
	// Use this class to implement CRUD operations on Redis

}
