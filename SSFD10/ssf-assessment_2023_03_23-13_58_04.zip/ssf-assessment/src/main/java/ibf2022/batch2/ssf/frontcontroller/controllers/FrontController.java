package ibf2022.batch2.ssf.frontcontroller.controllers;

public class FrontController {

	// TODO: Task 2, Task 3, Task 4, Task 6
	
}
