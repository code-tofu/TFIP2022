package ibf2022.batch2.ssf.frontcontroller.controllers;

public class ProtectedController {

	// TODO Task 5
	// Write a controller to protect resources rooted under /protected
}
